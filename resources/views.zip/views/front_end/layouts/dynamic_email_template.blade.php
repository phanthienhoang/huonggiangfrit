<h3>Hi, Tôi là {{ $data['name'] }}</h3>

<h3>{{ $data['message'] }}.</h3>

<h3>Email: {{ $data['email'] }}</h3>

<h3>Rất mong nhận được phản hồi của bạn sớm</h3>
