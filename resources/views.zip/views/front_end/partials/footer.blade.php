<footer>
    <!-- Footer Start-->
    <div class="footer-area footer-bg">
        <div class="container">
            <div class="row d-flex justify-content-between pt-5">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="single-footer-caption mb-50">
                        <div class="footer-tittle">
                            <h4>{{trans('header.company')}}</h4>
                            <ul>
                                <li>
                                <p><span><i class="fa fa-home" aria-hidden="true"></i>
                                </span>{{trans('header.address')}}</p>
                                </li>
                                <li><a href="#"><span><i class="fa fa-phone" aria-hidden="true"></i>
                                </span> +84.2343.595.695</a></li>
                                <li><a href="#"><span><i class="fa fa-envelope" aria-hidden="true"></i>
                                </span> huonggiangfrit@gmail.com</a></li>
                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- footer-bottom aera -->
    {{-- <div class="footer-bottom-area footer-bg">
        <div class="container">
            <div class="footer-border">
                 <div class="row d-flex justify-content-between align-items-center">
                     <div class="col-xl-10 col-lg-10 ">
                         <div class="footer-copy-right"> --}}
    <p>
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
        {{-- Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="ti-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a> --}}
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
    </p>
    {{-- </div>
                     </div>
                     <div class="col-xl-2 col-lg-2">
                         <div class="footer-social f-right">
                             <a href="#"><i class="fab fa-facebook-f"></i></a>
                             <a href="#"><i class="fab fa-twitter"></i></a>
                             <a href="#"><i class="fas fa-globe"></i></a>
                             <a href="#"><i class="fab fa-behance"></i></a>
                         </div>
                     </div>
                 </div>
            </div>
        </div>
    </div> --}}
    <!-- Footer End-->
</footer>